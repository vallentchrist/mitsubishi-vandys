-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 28 Mar 2021 pada 15.11
-- Versi server: 10.4.8-MariaDB
-- Versi PHP: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mitsubishi-vandys`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_promo`
--

CREATE TABLE `tb_promo` (
  `id` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `judul` varchar(100) NOT NULL,
  `deskripsi` text NOT NULL,
  `img_path` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tb_promo`
--

INSERT INTO `tb_promo` (`id`, `created`, `judul`, `deskripsi`, `img_path`) VALUES
(5, '2021-03-28 20:09:36', 'Promo Penjualan Maret 2021', '<p>PT Mitsubishi Motors Krama Yudha Sales Indonesia (MMKSI), distributor resmi kendaraan penumpang dan niaga ringan Mitsubishi di Indonesia dari Mitsubishi Motors Corporation (MMC), meneruskan suguhan program penjualan menarik bagi konsumen yang ingin memiliki lini kendaraan Mitsubishi Motors. Berbagai keuntungan dapat diperoleh konsumen yang ingin melakukan pembelian kendaraan Mitsubishi Motors pada bulan Maret 2021.</p><p>“Merupakan komitmen kami dalam memberikan kemudahan bagi konsumen yang ingin memiliki model kendaraan penumpang dan niaga ringan Mitsubishi Motors dengan berbagai penawaran dan program penjualan menarik. Konsumen dapat memanfaat pilihan program pembiayaan, gratis biaya jasa, gratis asuransi, serta keuntungan dari kebijakan insentif PPnBM 0% dengan potongan harga maksimal hingga Rp 18.000.000. Selain itu, konsumen juga mendapatkan kemudahan terkait perawatan dan perlindungan kendaraannya lewat rangkaian program purna jual dari Mitsubishi One,” jelas Naoya Nakamura, Presiden Direktur PT MMKSI.</p><p>Untuk mengetahui detail informasi tentang layanan penjualan MMKSI, konsumen dapat menghubungi dealer resmi Mitsubishi Motors terdekat, dengan lokasi yang tertera pada website resmi MMKSI <a href=\"https://www.mitsubishi-motors.co.id/cari-dealer\">https://www.mitsubishi-motors.co.id/cari-dealer</a> maupun melalui mobile apps My Mitsubishi Motors ID.</p><p>Rincian program penjualan yang dapat dinikmati oleh konsumen selama bulan Maret 2021 sebagai berikut:</p><p><strong>Xpander</strong></p><p>Khusus pembelian Xpander di bulan Maret 2021 akan mendapatkan:</p><p>1. Penerapan keringanan harga dengan perhitungan insentif PPnBM 0% , sesuai varian</p><figure class=\"table\"><table><tbody><tr><td rowspan=\"2\"><strong>Varian</strong></td><td colspan=\"5\"><strong>Angka insentif PPnBM 0%</strong></td></tr><tr><td colspan=\"2\"><strong>Non White Color</strong></td><td colspan=\"3\"><strong>White Color</strong></td></tr><tr><td>Xpander Ultimate</td><td>Rp</td><td colspan=\"2\">16,770,000</td><td>Rp</td><td>16,930,000&nbsp;</td></tr><tr><td>Xpander Sport AT</td><td>Rp</td><td colspan=\"2\">16,700,000</td><td>Rp</td><td>16,860,000&nbsp;</td></tr><tr><td>Xpander Sport MT</td><td>Rp</td><td colspan=\"2\">16,180,000</td><td>Rp</td><td>16,340,000&nbsp;</td></tr><tr><td>Xpander Exceed AT</td><td>Rp</td><td colspan=\"2\">15,570,000</td><td>Rp</td><td>15,730,000&nbsp;</td></tr><tr><td>Xpander Exceed MT</td><td>Rp</td><td colspan=\"2\">14,900,000</td><td>Rp</td><td>15,060,000&nbsp;</td></tr><tr><td>Xpander GLS AT</td><td>Rp</td><td colspan=\"2\">15,000,000</td><td>Rp</td><td>15,160,000&nbsp;</td></tr><tr><td>Xpander GLS MT</td><td>Rp</td><td colspan=\"2\">14,220,000</td><td>Rp</td><td>14,380,000&nbsp;</td></tr><tr><td>Xpander GLX MT</td><td>Rp</td><td colspan=\"2\">13,390,000</td><td>Rp</td><td>13,550,000&nbsp;</td></tr><tr><td>Xpander Black Edition AT</td><td>Rp</td><td colspan=\"2\">15,570,000</td><td>Rp</td><td>15,730,000&nbsp;</td></tr><tr><td>Xpander Black Edition MT</td><td>Rp</td><td colspan=\"2\">14,900,000</td><td>Rp</td><td>15,060,000&nbsp;</td></tr></tbody></table></figure><p>2. Pilihan program pembiayaan: bunga rendah 0% sampai dengan tenor 3 tahun, atau gratis asuransi 3 tahun, atau Gratis Asuransi 2 tahun dan Gopay 2 Juta serta Gratis Biaya Admin, atau cicilan ringan mulai dari 4 juta-an untuk pembiayaan melalui PT Dipo Star Finance (S&amp;K berlaku), atau</p><p>3. Program DP rendah mulai 15% dari PT Dipo Star Finance (S&amp;K berlaku), atau</p><p>4. Paket Smart Cash dengan bunga 0% selama 1 tahun dan gratis asuransi serta biaya admin ditambah Gopay s/d 3 Juta, melalui PT Dipo Star Finance (S&amp;K berlaku), atau</p><p>5. Program pembiayaan khusus karyawan dengan DP 20% gratis asuransi 2 tahun dengan tenor 6 tahun dari PT Dipo Star Finance</p>', 'xpander-black.png');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `tb_promo`
--
ALTER TABLE `tb_promo`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `tb_promo`
--
ALTER TABLE `tb_promo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
