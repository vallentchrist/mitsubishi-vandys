-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 05 Apr 2021 pada 16.15
-- Versi server: 10.4.8-MariaDB
-- Versi PHP: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mitsubishi-vandys`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_promo`
--

CREATE TABLE `tb_promo` (
  `id` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `judul` varchar(100) NOT NULL,
  `deskripsi` text NOT NULL,
  `img_path` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tb_promo`
--

INSERT INTO `tb_promo` (`id`, `created`, `judul`, `deskripsi`, `img_path`) VALUES
(1, '2021-04-05 20:39:33', 'Program Penjualan Mitsubishi Motors April 2021', '<p>PT. Mitsubishi Motors Krama Yudha Sales Indonesia (MMKSI), distributor resmi kendaraan penumpang dan niaga ringan Mitsubishi di Indonesia dari Mitsubishi Motors Corporation (MMC), meneruskan suguhan program penjualan menarik bagi konsumen yang ingin memiliki lini kendaraan Mitsubishi Motors. Berbagai keuntungan dapat diperoleh konsumen yang ingin melakukan pembelian kendaraan Mitsubishi Motors pada bulan April 2021.<br>&nbsp;</p><p>“Merupakan komitmen kami dalam memberikan kemudahan bagi konsumen yang ingin memiliki model kendaraan penumpang dan niaga ringan Mitsubishi Motors dengan berbagai penawaran dan program penjualan menarik. Konsumen dapat memanfaat pilihan program pembiayaan, gratis biaya jasa, gratis asuransi, serta keuntungan dari kebijakan insentif PPnBM 0% dengan potongan harga maksimal hingga Rp 18.000.000. Selain itu, konsumen juga mendapatkan kemudahan terkait perawatan dan perlindungan kendaraannya lewat rangkaian program purna jual dari Mitsubishi One,” jelas Naoya Nakamura, Presiden Direktur PT MMKSI.</p><p>Untuk mengetahui detail informasi tentang layanan penjualan MMKSI, konsumen dapat menghubungi dealer resmi Mitsubishi Motors terdekat, yaitu di Sardana Group yang berlokasi di jalan Gatot Subroto No. 437 Medan atau melalui kontak Whatsapp Official kami berikut<strong>: </strong><a href=\"https://api.whatsapp.com/send/?phone=628116541800&amp;text&amp;app_absent=0\"><strong>0823-7030-4974</strong></a>.</p><p>Rincian program penjualan yang dapat dinikmati oleh konsumen selama bulan April 2021 sebagai berikut:</p><p><strong>Xpander</strong></p><p>Khusus pembelian Xpander di bulan APRIL 2021 akan mendapatkan:</p><p>Penerapan keringanan harga dengan perhitungan insentif PPnBM 0%, sesuai varian</p><figure class=\"table\"><table><tbody><tr><td rowspan=\"2\"><strong>Varian</strong></td><td colspan=\"4\"><strong>Angka Insentif PPnBM 0%</strong></td></tr><tr><td colspan=\"2\"><strong>Non-White Color</strong></td><td colspan=\"2\"><strong>White Color</strong></td></tr><tr><td>Xpander Ultimate</td><td>Rp</td><td>16,770,000</td><td>Rp</td><td>16,930,000&nbsp;</td></tr><tr><td>Xpander Sport AT</td><td>Rp</td><td>16,700,000</td><td>Rp</td><td>16,860,000&nbsp;</td></tr><tr><td>Xpander Sport MT</td><td>Rp</td><td>16,180,000</td><td>Rp</td><td>16,340,000&nbsp;</td></tr><tr><td>Xpander Exceed AT</td><td>Rp</td><td>15,570,000</td><td>Rp</td><td>15,730,000&nbsp;</td></tr><tr><td>Xpander Exceed MT</td><td>Rp</td><td>14,900,000</td><td>Rp</td><td>15,060,000&nbsp;</td></tr><tr><td>Xpander GLS AT</td><td>Rp</td><td>15,000,000</td><td>Rp</td><td>15,160,000&nbsp;</td></tr><tr><td>Xpander GLS MT</td><td>Rp</td><td>14,220,000</td><td>Rp</td><td>14,380,000&nbsp;</td></tr><tr><td>Xpander GLX MT</td><td>Rp</td><td>13,390,000</td><td>Rp</td><td>13,550,000&nbsp;</td></tr><tr><td>Xpander Black Edition AT</td><td>Rp</td><td>15,570,000</td><td>Rp</td><td>15,730,000&nbsp;</td></tr><tr><td>Xpander Black Edition MT</td><td>Rp</td><td>14,900,000</td><td>Rp</td><td>15,060,000&nbsp;</td></tr></tbody></table></figure><ol><li>Program pembiayaan bunga rendah 0% sampai dengan tenor 2&nbsp;tahun,&nbsp;atau Gratis Asuransi 2 tahun untuk pembiayaan melalui PT Dipo Star Finance (S&amp;K berlaku)</li><li>Cicilan ringan mulai 4 jutaan atau</li><li>Program pembiayaan bunga rendah 0% sampai dengan tenor 2 tahun,&nbsp;atau gratis asuransi 2 tahun, untuk pembiayaan melalui PT Dipo Star Finance (S&amp;K berlaku)</li><li>Paket Smart Cash dengan bunga 0% selama 1 tahun dan gratis asuransi serta biaya admin ditambah Gopay melalui PT Dipo Star Finance (khusus untuk Xpander Black Edition)</li><li>Program pembiayaan khusus karyawan dengan DP 20%, gratis asuransi 2 tahun dengan tenor 6 tahun dari PT Dipo Star Finance</li><li>Gratis kaca film Konica Minolta</li><li>Gratis biaya jasa (sesuai dengan Service Manual Book) hingga 50.000 km atau 4 tahun untuk seluruh varian</li><li>Gratis Paket SMART SILVER untuk Perawatan/Servis Berkala hingga 50.000 km atau 4 tahun:</li><li>Suku cadang (sesuai dengan Service Manual Book)</li><li>Oli MMGO (sesuai dengan Service Manual Book)</li><li>Chemical item: Brake Fluid &amp; Engine Flush (sesuai dengan Service Manual Book)</li></ol><p>&nbsp;</p><p><strong>Xpander Cross</strong></p><p>Khusus pembelian Xpander Cross di bulan APRIL 2021 akan mendapatkan:&nbsp;</p><p>Penerapan keringanan harga dengan perhitungan insentif PPnBM 0% sesuai varian</p><figure class=\"table\"><table><tbody><tr><td rowspan=\"2\"><strong>Varian</strong></td><td colspan=\"4\"><strong>Angka Insentif PPnBM 0%</strong></td></tr><tr><td colspan=\"2\"><strong>Non-White Color</strong></td><td colspan=\"2\"><strong>White Color</strong></td></tr><tr><td>Xpander Cross Premium</td><td>Rp</td><td>18,140,000</td><td>Rp</td><td>18,300,000&nbsp;</td></tr><tr><td>Xpander Cross AT</td><td>Rp</td><td>17,680,000</td><td>Rp</td><td>17,840,000&nbsp;</td></tr><tr><td>Xpander Cross MT</td><td>Rp</td><td>16,960,000</td><td>Rp</td><td>17,120,000&nbsp;</td></tr><tr><td>Xpander Cross Rockford Fosgate Black Edition</td><td>Rp</td><td>18,140,000</td><td>Rp</td><td>18,300,000</td></tr></tbody></table></figure><p>&nbsp;</p><ol><li>Program&nbsp;pembiayaan bunga rendah 0% sampai dengan tenor 2&nbsp;tahun, atau gratis asuransi 2 tahun + Gopay + gratis biaya admin, atau cicilan ringan mulai dari&nbsp;3&nbsp;juta-an untuk pembiayaan melalui PT Dipo Star Finance (S&amp;K berlaku)</li><li>Program pembiayaan bunga rendah 0% sampai dengan tenor 3 tahun khusus untuk Xpander Cross AT Tahun Perakitan 2019 melalui PT Dipo Star Finance</li><li>Program&nbsp;pembiayaan SMART CASH dengan bunga 0% selama 1 tahun, gratis asuransi &amp; biaya admin dari PT Dipo Star Finance</li><li>Promo spesial karyawan dengan DP 20% tenor 6 tahun dan gratis asuransi selama 2 tahun</li><li>Gratis kaca film V-Kool untuk variant A/T Premium dan kaca film Konika Minolta untuk variant A/T &amp; M/T</li><li>Gratis biaya jasa (sesuai dengan Service Manual Book) hingga 50.000 km atau 4 tahun untuk seluruh varian</li><li>Gratis Paket SMART SILVER untuk Perawatan/Servis Berkala hingga 50.000 km atau 4 tahun:</li><li>Suku cadang (sesuai dengan Service Manual Book)</li><li>Oli MMGO (sesuai dengan Service Manual Book)</li><li>Chemical item: Brake Fluid &amp; Engine Flush (sesuai dengan Service Manual Book</li></ol><p>&nbsp;</p><p><strong>New Pajero Sport</strong></p><p>Khusus pembelian New Pajero Sport di bulan APRIL 2021 akan mendapatkan:&nbsp;</p><ol><li>Pilihan program pembiayaan dengan bunga ringan, atau DP ringan dari PT Dipo Star Finance (S&amp;K berlaku), atau</li><li>Program Tabungan emas senilai Rp 5.000.000 untuk pembelian New Pajero Sport melalui pembiayaan PT Dipo Star Finance (S&amp;K berlaku).</li><li>Kemudahan dan keuntungan biaya perawatan dengan SMART Package Silver</li><li>Gratis Kaca Film V-Kool</li><li>Gratis biaya jasa (sesuai dengan Service Manual Book) hingga 50.000 km atau 4 tahun untuk seluruh varian</li><li>Gratis Paket SMART SILVER untuk Perawatan/Servis Berkala hingga 50.000 km atau 4 tahun:</li></ol><ul><li>Suku cadang (sesuai dengan Service Manual Book)</li><li>Oli MMGO (sesuai dengan Service Manual Book)</li><li>Chemical item: Diesel Fuel System Flush, Engine Flush</li></ul><p>&nbsp;</p><p><strong>Eclipse Cross</strong></p><p>Khusus pembelian Eclipse Cross di bulan APRIL 2021 akan mendapatkan:&nbsp;</p><ol><li>Pilihan&nbsp;Program pembiayaan bunga 0% sampai dengan tenor 1 tahun, atau gratis asuransi 2 tahun melalui pembiayaan PT Dipo Star Finance&nbsp;(S&amp;K berlaku), atau</li><li>Gratis biaya jasa dan suku cadang (sesuai dengan Service Manual Book) hingga 50.000 km atau 4 tahun</li><li>Gratis kaca film V-Kool</li></ol><p>&nbsp;</p><p><strong>Outlander PHEV</strong></p><p>Khusus pembelian Outlander PHEV di bulan APRIL 2021 akan mendapatkan:&nbsp;</p><ol><li>Pilihan program pembiayaan bunga 0% sampai dengan tenor 1 tahun, atau gratis asuransi 2 tahun melalui PT Dipo Star Finance&nbsp;(S&amp;K berlaku), atau</li><li>Gratis biaya jasa dan suku cadang (sesuai dengan Service Manual Book) hingga 50.000 km atau 4 tahun</li><li>Gratis kaca film V-Kool</li><li>Gratis standard AC Home Charger beserta instalasinya</li><li>Cashback subsidi tagihan listrik senili 3.200.000 untuk validasi April 2021</li></ol><p>&nbsp;</p><p><strong>Triton 4x4</strong></p><p>Khusus pembelian Triton 4x4 di bulan APRIL 2021 akan mendapatkan:&nbsp;</p><ol><li>Program penawaran khusus dari leasing tertentu</li><li>Gratis Ban MT untuk varian SC &amp; DC HDX</li><li>Gratis biaya jasa dan suku cadang (sesuai dengan Service Manual Book) hingga 40.000 km atau 2 tahun untuk semua varian</li></ol><p>&nbsp;</p><p><strong>Triton 4x2 dan L300</strong></p><p>Khusus pembelian Triton 4x2 dan L300 di bulan APRIL 2021 akan mendapatkan program penawaran khusus dari leasing tertentu.</p><p>&nbsp;</p><p><strong>Hubungi Kami</strong></p><p>Seluruh program memiliki syarat dan ketentuan berlaku. Untuk informasi dan penawaran lebih lanjut dapat menghubungi kami di kontak Whatsapp Official kami berikut<strong>: </strong><a href=\"https://api.whatsapp.com/send/?phone=628116541800&amp;text&amp;app_absent=0\"><strong>0822-7030-4974</strong></a>&nbsp;(Vandystio Danatho) atau melalui no. telepon dealer terdekat Anda :</p><p><strong>PT. Sardana IndahBerlian Motor</strong></p><p>Jl. Gatot Subroto No. 437, Medan&nbsp; -&nbsp; Telp. (061) 455 7800<br>Jl. Putri Hijau No. 4A, Medan&nbsp; -&nbsp; Telp. (061) 8051 3800<br>Jl. Boulevard Barat No. 8 Bundaran Komp Cemara Asri Medan -&nbsp; Telp (061) 8001 1800</p>', '606b131523dd2.jpg');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `tb_promo`
--
ALTER TABLE `tb_promo`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `tb_promo`
--
ALTER TABLE `tb_promo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
